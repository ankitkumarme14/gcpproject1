package com.ankit.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ankit.Repository.StudentRepository;
import com.ankit.entity.Student;

@Service
public class StudentServicerImp implements StudentService {
	
	@Autowired
	private StudentRepository studentRepository;

	@Override
	public Student saveDetails(Student student) {
		Student st=studentRepository.save(student);
		return st;
	}

	@Override
	public List<Student> getAllStudents() {
		List<Student> list=studentRepository.showAll();
		//List<Student> list=studentRepository.findAll();
		return list;
	}

}
