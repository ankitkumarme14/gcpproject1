package com.ankit.service;

import java.util.List;

import com.ankit.entity.Student;

public interface StudentService {

	Student saveDetails(Student student);

	List<Student> getAllStudents();

}
