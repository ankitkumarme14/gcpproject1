package com.ankit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Gcpproject1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
